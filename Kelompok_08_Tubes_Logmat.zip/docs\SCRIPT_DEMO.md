# 🎬 SCRIPT DEMO - SISTEM PAKAR MITIGASI BENCANA BANJIR

## 📋 **PERSIAPAN SEBELUM DEMO**

### Checklist:
- ✅ Server Flask sudah running (`python web_app_enhanced.py`)
- ✅ Browser terbuka di `localhost:5000`
- ✅ Tab "Analisis" sudah aktif
- ✅ Semua toggle dalam kondisi OFF (FALSE)
- ✅ Refresh browser untuk kondisi awal yang bersih

---

## 🎤 **SCRIPT PRESENTASI**

### **BAGIAN 1: PEMBUKAAN** (1-2 menit)

**[Tampilkan landing page]**

> "Selamat pagi/siang Bapak/Ibu, teman-teman semua. Perkenalkan, kami dari **Kelompok 8** akan mempresentasikan proyek kami yang berjudul **Sistem Pakar Mitigasi Bencana Alam Berbasis Logika Proposisional**."

**[Scroll perlahan ke bagian team]**

> "Tim kami terdiri dari 3 orang: Agna Khoerunnisa sebagai Frontend Developer, Muhdan Firdaus Salam sebagai Backend Developer, dan Muhamad Ilman Pauji sebagai Project Manager."

**[Scroll ke atas lagi]**

> "Sistem ini dirancang untuk membantu masyarakat memahami risiko banjir di wilayah mereka menggunakan pendekatan logika matematika yang sederhana namun efektif."

---

### **BAGIAN 2: KONSEP DASAR** (2-3 menit)

**[Klik tab "Analisis"]**

> "Baik, sekarang kita masuk ke bagian inti dari sistem ini."

**[Tunjuk ke bagian Input Variabel]**

> "Sistem kami menggunakan **3 variabel proposisional** untuk mengevaluasi risiko banjir:"

**[Tunjuk satu per satu]**

1. > "**Variabel p** - Curah Hujan Tinggi. Ini bernilai TRUE jika curah hujan lebih dari 100mm per hari."

2. > "**Variabel q** - Alih Fungsi Lahan Sawit. TRUE jika ada deforestasi atau konversi lahan yang signifikan."

3. > "**Variabel r** - Sungai Dangkal/Sempit. TRUE jika sistem drainase buruk atau terjadi sedimentasi."

**[Tunjuk ke bagian Formula Logika]**

> "Ketiga variabel ini kemudian dievaluasi menggunakan **formula logika proposisional** yang sederhana tapi powerful: **S = p ∧ (q ∨ r)**"

> "Artinya: Risiko banjir terjadi JIKA ada hujan tinggi **DAN** minimal satu dari kondisi lahan rusak **ATAU** sungai buruk."

---

### **BAGIAN 3: DEMO INTERAKTIF** (5-7 menit)

#### **Skenario 1: Kondisi Ideal (Semua Aman)**

**[Pastikan semua toggle OFF]**

> "Mari kita coba skenario pertama. Kondisi ideal dimana semua variabel bernilai FALSE."

**[Tunggu hasil muncul - harus menampilkan KONDISI AMAN]**

> "Seperti yang bisa kita lihat:"
> - "Di bagian **Langkah Perhitungan**, sistem menunjukkan bahwa q OR r menghasilkan FALSE, dan p AND FALSE juga FALSE."
> - "**Status** menunjukkan hijau dengan label **KONDISI AMAN**."
> - "Dan sistem memberikan **rekomendasi** untuk tetap waspada dan pantau cuaca."

**[Scroll ke Tabel Kebenaran]**

> "Nah, yang menarik adalah di **Tabel Kebenaran** ini. Lihat, baris pertama dengan semua FALSE **ter-highlight kuning** - ini menunjukkan kondisi kita saat ini dari total 8 kemungkinan kombinasi."

---

#### **Skenario 2: Hujan Saja (Tetap Aman)**

**[Toggle HANYA p = ON]**

> "Sekarang kita coba skenario kedua. Misalkan ada hujan tinggi, tapi kondisi lahan dan sungai masih bagus."

**[Tunggu hasil update]**

> "Menarik! Meskipun ada hujan tinggi, sistem tetap menunjukkan **KONDISI AMAN**. Mengapa?"

**[Tunjuk ke Langkah Perhitungan]**

> "Karena q OR r menghasilkan FALSE, dan TRUE AND FALSE tetap FALSE. Ini menunjukkan bahwa hujan saja tidak cukup untuk menyebabkan banjir jika infrastruktur dan lingkungan dalam kondisi baik."

**[Scroll ke Tabel Kebenaran]**

> "Dan lihat, highlight-nya pindah ke baris yang sesuai - **baris ke-5** dimana p=TRUE, q=FALSE, r=FALSE."

---

#### **Skenario 3: Hujan + Lahan Rusak (BAHAYA!)**

**[Toggle p = ON, q = ON, r = OFF]**

> "Nah, sekarang kita akan lihat kondisi berbahaya. Hujan tinggi **DAN** lahan rusak."

**[Tunggu hasil update - harus MERAH]**

> "**PERINGATAN BANJIR!** Status berubah menjadi merah dengan animasi pulse yang menarik perhatian."

**[Tunjuk detail]**

> "Perhatikan trace perhitungannya:"
> - "q OR r = TRUE OR FALSE = **TRUE**"
> - "p AND TRUE = TRUE AND TRUE = **TRUE**"
> - "Hasilnya: **BANJIR TERDETEKSI**"

> "Dan sistem langsung memberikan rekomendasi yang lebih serius: evakuasi dan tindakan mitigasi segera diperlukan."

**[Scroll ke Tabel Kebenaran]**

> "Di tabel kebenaran, kita bisa lihat ini adalah **Skenario #7** - salah satu dari 3 skenario berbahaya. Dan background-nya merah menandakan risiko tinggi."

---

#### **Skenario 4: Kondisi Paling Kritis**

**[Toggle SEMUA = ON (p, q, r)]**

> "Dan sekarang, worst case scenario - semua kondisi buruk terjadi bersamaan."

**[Tunggu hasil update]**

> "Ini adalah **Skenario #8** - kondisi paling kritis! Semua faktor risiko aktif:"
> - "Hujan sangat tinggi ✓"
> - "Lahan tidak bisa menyerap air ✓"  
> - "Sistem drainase sudah jenuh ✓"

> "Dalam kondisi seperti ini, risiko banjir bandang sangat tinggi dengan waktu respons yang sangat minimal. Evakuasi harus dilakukan segera!"

---

### **BAGIAN 4: FITUR LANJUTAN** (2-3 menit)

#### **A. Statistik Real-time**

**[Klik tab "Statistik"]**

> "Sistem kami juga menyimpan riwayat semua analisis yang dilakukan."

**[Tunjuk grafik dan angka]**

> "Di sini kita bisa lihat:"
> - "Total berapa kali analisis dilakukan"
> - "Berapa kali kondisi bahaya terdeteksi"
> - "Tren risiko dalam bentuk grafik"
> - "Distribusi variabel yang paling sering TRUE"

---

#### **B. Mode Simulasi**

**[Klik tab "Simulasi"]**

> "Ada juga mode simulasi yang memudahkan kita testing berbagai skenario dengan cepat."

**[Klik salah satu button skenario]**

> "Cukup klik salah satu skenario preset, dan sistem langsung mengevaluasi kondisi tersebut."

---

#### **C. Integrasi Data Cuaca Real-time**

**[Klik tab "Cuaca"]**

> "Yang membuat sistem ini lebih praktis, kami mengintegrasikan dengan **OpenWeather API** untuk mendapatkan data cuaca real-time."

**[Ketik nama kota, misalnya "Jakarta"]**

> "Kita bisa cari data cuaca kota manapun di Indonesia..."

**[Tunggu loading]**

> "Dan sistem akan menampilkan:"
> - "Kondisi cuaca saat ini dengan **animasi visual** - lihat ada animasi hujan/awan yang bergerak!"
> - "Prakiraan 5 hari ke depan dengan grafik interaktif"
> - "Prakiraan per jam dalam format yang mudah dibaca"
> - "Tips khusus berdasarkan kondisi cuaca"

**[Scroll ke grafik forecast]**

> "Bahkan ada grafik tren suhu yang interaktif - hover untuk lihat detail tiap titik."

---

### **BAGIAN 5: KEUNGGULAN SISTEM** (1-2 menit)

**[Kembali ke tab Analisis, scroll ke bagian Tabel Kebenaran]**

> "Jadi, apa keunggulan sistem kami?"

**[Sambil tunjuk-tunjuk]**

**1. Berbasis Logika Matematika yang Solid**
> "Menggunakan logika proposisional yang sudah terbukti dan dapat diverifikasi kebenarannya."

**2. Transparan dan Explainable**
> "Setiap keputusan bisa ditelusuri langkah demi langkah. Tidak seperti black box machine learning."

**3. Mudah Dipahami**
> "Bahkan orang awam bisa memahami bagaimana sistem mengambil keputusan."

**4. Real-time dan Interaktif**
> "Update langsung saat kondisi berubah, dengan visualisasi yang jelas."

**5. Comprehensive**
> "Dari input, analisis, tabel kebenaran, hingga rekomendasi mitigasi - semua dalam satu sistem."

---

### **BAGIAN 6: PENUTUP** (1 menit)

**[Scroll ke bagian statistik di tab Analisis]**

> "Dari total 8 kemungkinan kombinasi kondisi:"
> - "**5 skenario (62.5%)** menghasilkan kondisi aman"
> - "**3 skenario (37.5%)** menghasilkan risiko banjir"

> "Yang paling penting, sistem ini menunjukkan bahwa **curah hujan tinggi adalah necessary condition** - tanpa hujan tinggi, banjir tidak akan terjadi dalam model kami."

**[Kembali ke landing page]**

> "Sistem ini bukan hanya tugas kuliah, tapi kami berharap bisa memberikan manfaat nyata untuk:"
> - "Edukasi masyarakat tentang faktor risiko banjir"
> - "Membantu keputusan evakuasi dini"
> - "Referensi untuk lembaga penanggulangan bencana lokal"

> "Sekian presentasi dari kami. Terima kasih atas perhatiannya. Kami siap menjawab pertanyaan."

---

## 👥 **PEMBAGIAN TUGAS TIM UNTUK VIDEO DEMO**

### **Overview Pembagian:**

Untuk membuat video demo yang profesional dan efisien, berikut pembagian tugas untuk 3 anggota tim dengan fokus yang jelas:

---

### **⚙️ MUHDAN FIRDAUS SALAM** (Backend Developer)
**Role:** Ngejelasin Behind The Scenes - Gimana sistemnya jalan di dalem  
**Durasi:** ~8-10 menit

#### **Bagian yang Lo Pegang:**

1. **BAGIAN 1: Opening & Ngenal-nalin Sistemnya** (2 menit)
   - Hai-hai dulu, kenalan sama tim
   - "Jadi ceritanya nih, sistem kita tuh dibagi dua ya - ada frontend sama backend..."
   - Cerita tech stack yang dipake: "Gue pake Python Flask buat backend, kenapa? Karena..."

2. **BAGIAN 2: Ngupas Logika & Implementasinya** (3-4 menit)
   - "Oke, jadi sistem kita pake 3 variabel nih. Simpel tapi powerful!"
   - Jelasin p, q, r dengan contoh real: "Misalnya p itu hujan deras ya, yang kalo lo keluar rumah langsung basah kuyup gitu..."
   - Formula S = p ∧ (q ∨ r): "Nah, rumus ini basically bilang: banjir bakal terjadi kalo hujan gede DAN (lahan rusak ATAU sungai jelek). Masuk akal kan?"
   - "Kenapa cuma 3 variabel? Ya karena ini yang paling impact! Gausah ribet-ribet, yang penting effectivenya dapet."

3. **BAGIAN 3: Tour Kode Bareng Gue** (3-4 menit)
   - "Cus gue buka VS Code nya... Ini nih file web_app_enhanced.py"
   - Share screen, scroll sambil jelasin:
     * "Fungsi `calculate_flood_risk()` ini basically otak dari sistemnya..."
     * "Terus Flask route-nya disini - ini yang nge-handle request dari frontend"
     * "Nah yang ini API cuaca - gue integrasiin OpenWeather biar dapet data real-time"
   - "Gimana flow-nya? Gini nih: User klik toggle → data masuk ke backend gue → gue proses pake logika → hasilnya balik ke frontend. Simple!"

#### **Tips Recording Buat Lo:**
- ✅ Buka VS Code, bikin kelihatan keren (pake dark theme, font gedean dikit)
- ✅ Jangan buru-buru! Scroll pelan, kasih waktu mereka cerna
- ✅ Jelasin kayak lagi ngajarin temen: "Jadi intinya gini nih..."
- ✅ Sesekali bilang "Ngerti ya sampe sini?" buat bikin engaging
- ✅ Kalo ada yang tricky, bilang: "Nah ini bagian yang agak tricky, tapi gampang kok..."
- ✅ Tone: Santai tapi tetep keliatan ngerti - jangan kaku!

#### **Tools yang Lo Butuhin:**
- VS Code (pake theme Dracula/Material, cakep di video)
- OBS buat record (atur bitrate yang oke ya)
- Terminal buka di samping buat show logs: "Liat nih, pas gue jalanin server..."
- Browser DevTools (Network tab): "Nah ini request-nya masuk... status 200 OK, mantap!"

#### **Yang HARUS Lo Jelasin (Pake Bahasa Lo Sendiri):**

**1. Fungsi Inti:**
> "Coba deh liat fungsi ini. Simpel banget kan? Cuma return `p and (q or r)`. But that's the beauty of it! Logika proposisional tuh straightforward - gak usah ribet machine learning segala."

```python
def calculate_flood_risk(p, q, r):
    # Ini rumus sederhana tapi powerful
    q_or_r = q or r  # Lahan rusak ATAU sungai jelek
    result = p and q_or_r  # Hujan DAN salah satu di atas
    return result
```

**2. API Weather:**
> "Nah yang ini gue proud nih - integrasi sama OpenWeather API. Jadi real-time data cuaca langsung masuk ke sistem kita. Keren kan?"

**3. Kenapa Pake Flask?**
> "Kenapa Flask? Ya karena lightweight, cepet, gampang setup. Perfect buat project kayak gini. Plus dokumentasinya lengkap banget!"

**4. Data Flow:**
> "Flow-nya gini: Frontend kirim data → Backend gue terima via POST → Proses pake fungsi calculate → Return JSON ke frontend. Clean and simple!"

---

### **🎨 AGNA KHOERUNNISA** (Frontend Developer)
**Role:** Visualisasi & User Experience  
**Durasi:** ~7-9 menit

#### **Bagian yang Dipegang:**
1. **BAGIAN 3: Demo Interaktif** (5-6 menit)
   - Walkthrough UI/UX design sistem
   - Demo 4 skenario dengan fokus pada VISUAL FEEDBACK:
     * Skenario 1: Kondisi Ideal (Hijau)
     * Skenario 2: Hujan Saja (Masih Hijau)
     * Skenario 3: Hujan + Lahan Rusak (Merah - Bahaya!)
     * Skenario 4: Worst Case (Merah - Kritis!)
   - **Fokus:** Animasi, transisi, feedback visual ke user
   - Tunjukkan highlight di Tabel Kebenaran setiap skenario

2. **BAGIAN 4: Fitur Lanjutan (Visual Focus)** (2-3 menit)
   - **Tab Statistik:** Grafik dan visualisasi data
     * Total analisis
     * Kondisi bahaya terdeteksi
     * Tren risiko dalam grafik
   - **Tab Simulasi:** Demo preset scenarios
     * Quick testing berbagai skenario
   - **Tab Cuaca:** Animasi cuaca real-time
     * Demo animasi hujan, awan, cerah (CSS animations!)
     * Grafik prakiraan 5 hari interaktif
     * Hover effects pada grafik
   - Highlight bagian-bagian UI yang menarik:
     * Pulse animation saat bahaya
     * Color coding (hijau/merah)
     * Smooth transitions
   - **Fokus:** Estetika dan user-friendly interface

#### **Tips Recording:**
- ✅ Full screen browser, zoom 100%
- ✅ Slow motion saat toggle untuk tunjukkan animasi
- ✅ Highlight cursor untuk emphasize area tertentu
- ✅ Tunjukkan hover effects dan micro-interactions
- ✅ Record dalam 1080p untuk clarity
- ✅ Tone: Friendly, engaging, enthusiastic

#### **Tools yang Dibutuhkan:**
- OBS Studio / Camtasia
- Cursor highlighter tool
- Good microphone
- Script untuk smooth narration

#### **Poin Penting yang Harus Dijelaskan:**
- Bagaimana warna membantu user memahami risiko (green/red)
- Animasi pulse untuk menarik perhatian saat bahaya
- Tabel kebenaran interaktif dengan highlight
- Responsiveness di berbagai device (opsional: tunjukkan mobile view)
- CSS animations untuk cuaca (rain drops, clouds)

---

### **📊 MUHAMAD ILMAN PAUJI** (Project Manager)
**Role:** Evaluasi Sistem - Keunggulan & Kekurangan  
**Durasi:** ~5-6 menit

#### **Bagian yang Dipegang:**
1. **BAGIAN 5: Keunggulan Sistem** (2-3 menit)
   **5 Keunggulan Utama:**
   - ✅ **Berbasis Logika Matematika yang Solid**
     * Explainable AI - setiap keputusan bisa dibuktikan
     * Tidak seperti black box ML
   
   - ✅ **Sederhana namun Efektif**
     * Hanya 3 variabel, mudah dipahami masyarakat
     * Tidak perlu expertise untuk menggunakan
   
   - ✅ **Real-time Integration**
     * Integrasi dengan OpenWeather API
     * Data cuaca aktual, bukan asumsi
   
   - ✅ **Comprehensive Output**
     * Tidak hanya "Ya/Tidak" - ada penjelasan detail
     * Langkah perhitungan transparan
     * Rekomendasi mitigasi spesifik
   
   - ✅ **User-Friendly Interface**
     * Visual yang menarik dan intuitif
     * Animasi membantu pemahaman
     * Bisa digunakan siapa saja

2. **Kekurangan & Keterbatasan Sistem** (1-2 menit)
   **Honest Assessment:**
   - ⚠️ **Keterbatasan Variabel**
     * Hanya 3 faktor - realitas lebih kompleks
     * Belum memperhitungkan: topografi, pasang surut, dll.
   
   - ⚠️ **Threshold Statis**
     * 100mm/hari fixed - berbeda tiap daerah
     * Perlu kalibrasi per wilayah
   
   - ⚠️ **Ketergantungan Data Eksternal**
     * Butuh API key dan internet
     * Jika API down, fitur cuaca tidak jalan
   
   - ⚠️ **Belum Teruji Luas**
     * Baru divalidasi dengan data terbatas
     * Perlu testing lebih luas di lapangan
   
   - ⚠️ **No Predictive Capability**
     * Sistem reaktif (real-time) bukan prediktif
     * Belum ada forecasting banjir jangka panjang

3. **BAGIAN 6: Penutup & Future Development** (1-2 menit)
   - Potensi pengembangan:
     * Tambah variabel (topografi, pasang surut)
     * Machine learning untuk prediksi jangka panjang
     * Integrasi IoT sensor
     * Mobile app untuk notifikasi
     * Peta interaktif zona risiko
   - Closing statement yang impactful
   - Terima kasih dan Q&A

#### **Tips Recording:**
- ✅ Gunakan slide sederhana untuk list keunggulan/kekurangan
- ✅ Tone: Honest, balanced, visionary
- ✅ Jangan defensive - akui kekurangan dengan solusi
- ✅ End with positive note tentang masa depan
- ✅ Optional: Face cam untuk lebih personal

#### **Tools yang Dibutuhkan:**
- PowerPoint/Google Slides (simple, clean design)
- Screen recording atau face cam
- Background yang rapih
- Good lighting untuk face recording

#### **Struktur Slide Suggestion:**
```
Slide 1: "5 KEUNGGULAN SISTEM"
- List dengan icon checkmark

Slide 2: "KETERBATASAN & AREA IMPROVEMENT"  
- List dengan icon warning
- Paired dengan "How to solve" di sebelah

Slide 3: "FUTURE ROADMAP"
- Timeline atau mind map pengembangan

Slide 4: "THANK YOU"
- Contact info, GitHub link
```

---

## 🎬 **TIMELINE PRODUKSI VIDEO**

### **Minggu 1: Pre-Production**
- **Hari 1-2:** Review script dan finalisasi pembagian
- **Hari 3:** Latihan individual (masing-masing bagian)
- **Hari 4:** Latihan full run dengan koordinasi timing

### **Minggu 2: Production**
- **Hari 1:** Recording Agna (Bagian 1-3)
- **Hari 2:** Recording Muhdan (Bagian 4 + Behind Scenes)
- **Hari 3:** Recording Ilman (Bagian 5-6)
- **Hari 4:** Backup recording & retakes

### **Minggu 3: Post-Production**
- **Hari 1-2:** Editing & merging semua footage
- **Hari 3:** Add transitions, music, captions
- **Hari 4:** Review, revisi, dan export final

---

## 🎥 **KOORDINASI & TRANSITION ANTAR BAGIAN**

### **Transition 1: Muhdan → Agna**
**Di akhir Code Walkthrough (Muhdan):**
> "Oke deh, jadi itu tadi backend-nya - basically gimana 'otak' sistem ini jalan dari belakang layar. Simpel kan? Logika matematika yang straightforward, terus diimplementasi pake Python yang clean. Nah sekarang, lo pasti penasaran dong gimana tampilannya ke user? Gue serahin ke Agna deh buat show off visual-nya. Agna, tunjukin dong kerennya!"

**Di awal Demo Visualisasi (Agna):**
> "Thanks Dan! Oke guys, tadi Muhdan udah jelasin 'otak'-nya kan - sekarang gue tunjukin 'wajah'-nya. Gimana caranya kita bikin logika yang technically complex tadi jadi user-friendly dan enak dilihat. Let me show you..."

---

### **Transition 2: Agna → Ilman**
**Di akhir Fitur Lanjutan (Agna):**
> "Jadi itu dia tampilan dan pengalaman user saat menggunakan sistem kita - mulai dari demo interaktif sampai fitur-fitur visualnya. Dari sisi visual, kami usahakan semudah dan semenarik mungkin. Sekarang, Ilman akan kasih evaluasi lengkap tentang kekuatan dan keterbatasan sistem kita."

**Di awal Keunggulan (Ilman):**
> "Terima kasih Agna! Oke, setelah Muhdan jelaskan technical implementation-nya dan Agna tunjukkan visual experience-nya, sekarang saya akan kasih honest evaluation - apa saja keunggulan sistem ini, apa keterbatasannya, dan bagaimana kita bisa develop lebih lanjut ke depan..."

---

## 📋 **CHECKLIST INDIVIDUAL**

### **Untuk Muhdan:**
- [ ] Buka dan pahamin dulu semua isi `web_app_enhanced.py` - jangan sampai keliatan bingung pas jelasin
- [ ] Setup VS Code yang cakep (theme dark, font agak gede) biar enak diliat di video
- [ ] Tandain bagian-bagian kode yang mau lo tunjukin - jangan sampe scroll kebingungan
- [ ] Kalo sempet, bikin diagram alur simpel (tapi jangan lama-lama, optional kok)
- [ ] Jalanin server dulu, liat logs-nya jalan normal
- [ ] Practice jelasin fungsi-fungsi inti pake bahasa lo sendiri - jangan kaku bacain doang
- [ ] Record 2-3 kali, pilih yang paling natural dan confident
- [ ] PENTING: Latihan dulu! Jelasin ke cermin atau temen sampe lancar

### **Untuk Agna:**
- [ ] Test semua animasi dan pastikan smooth
- [ ] Siapkan kondisi awal browser (semua toggle OFF)
- [ ] Install cursor highlighter tool
- [ ] Praktek timing toggle dengan jeda yang pas
- [ ] Prepare browser dengan tab-tab yang akan di-demo
- [ ] Test responsive view (optional mobile demo)
- [ ] Record dengan resolusi 1080p

### **Untuk Ilman:**
- [ ] Buat slide sederhana untuk keunggulan & kekurangan
- [ ] List 5 keunggulan dengan penjelasan singkat
- [ ] List 4-5 kekurangan dengan honest assessment
- [ ] Prepare future roadmap ideas
- [ ] Praktek tone yang balanced (jujur tapi positif)
- [ ] Setup lighting dan background untuk face recording
- [ ] Prepare closing statement yang memorable

---

## 🎯 **TIPS KOLABORASI TIM**

### **Do's:**
- ✅ Sync di awal: Pastikan semua paham flow keseluruhan
- ✅ Consistent branding: Gunakan intro/outro yang sama
- ✅ Share footage: Upload ke Google Drive/Dropbox shared
- ✅ Review bersama: Tonton hasil editing bersama sebelum final
- ✅ Backup everything: Save raw files minimal 2 tempat

### **Don'ts:**
- ❌ Record terpisah tanpa koordinasi timing
- ❌ Pakai style recording yang beda-beda drastis
- ❌ Edit sendiri-sendiri tanpa guideline
- ❌ Last minute rush - mulai jauh-jauh hari
- ❌ Lupa cross-check konten yang overlap

---

## 🎨 **VISUAL GUIDELINES**

### **Consistency yang Harus Dijaga:**

1. **Screen Resolution:** Semua recording 1920x1080 (Full HD)
2. **Browser Zoom:** 100% (jangan zoom in/out)
3. **Cursor Highlight:** Gunakan tools yang sama (seperti Cursor Highlighter)
4. **Font Size:** Pastikan readable di layar kecil
5. **Audio Quality:** Minimal 128kbps, no background noise

### **Branding Elements:**

```
INTRO SLIDE (5 detik):
━━━━━━━━━━━━━━━━━━━━━━━━━━━
  SISTEM PAKAR MITIGASI BANJIR
  Berbasis Logika Proposisional
  
  Kelompok 8:
  • Agna Khoerunnisa
  • Muhdan Firdaus Salam  
  • Muhamad Ilman Pauji
━━━━━━━━━━━━━━━━━━━━━━━━━━━

TRANSITION SLIDE (3 detik):
━━━━━━━━━━━━━━━━━━━━━━━━━━━
  [Nama Bagian]
  Presenter: [Nama]
━━━━━━━━━━━━━━━━━━━━━━━━━━━

OUTRO SLIDE (5 detik):
━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Terima Kasih!
  
  Questions?
  
  GitHub: [link jika ada]
  Email: [email kelompok]
━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## 🎵 **AUDIO & MUSIC SUGGESTIONS**

### **Background Music (Low Volume):**
- **Intro/Outro:** Upbeat, energetic (contoh: YouTube Audio Library - "Inspiring")
- **Demo Section:** Soft ambient, tidak mengganggu voiceover
- **Technical Section:** Slightly techy vibe (electronic-ish)
- **Closing:** Uplifting, inspiring

### **Volume Levels:**
- Voiceover: 100% (paling loud)
- Background Music: 15-20% (subtle)
- System Sounds: 30-40% (cukup terdengar)

---

## 📊 **FINAL VIDEO STRUCTURE**

```
TIMELINE (Total ~20-23 menit):

00:00 - 00:05  | Intro Slide + Music
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
00:05 - 02:05  | Muhdan: Opening & ngenalin sistemnya
02:05 - 06:05  | Muhdan: Ngupas konsep logika & gimana implementasinya
06:05 - 10:05  | Muhdan: Tour kode bareng (Behind the scenes)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
10:05 - 10:08  | Transition Slide
10:08 - 15:08  | Agna: BAGIAN 3 - Demo Interaktif (4 Skenario)
15:08 - 18:08  | Agna: BAGIAN 4 - Fitur Lanjutan (Stats, Simulasi, Cuaca)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
18:08 - 18:11  | Transition Slide  
18:11 - 20:41  | Ilman: BAGIAN 5 - Keunggulan Sistem (5 poin)
20:41 - 22:11  | Ilman: Kekurangan & Keterbatasan (Honest Assessment)
22:11 - 23:41  | Ilman: BAGIAN 6 - Future Development & Closing
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
23:41 - 23:46  | Outro Slide + Credits
```

---

## 💬 **COMMUNICATION PLAN**

### **WhatsApp Group Rules:**
1. **Update Progress:** Post daily progress update
2. **Share Files:** Link ke Google Drive, bukan kirim langsung
3. **Quick Sync:** VC singkat jika ada blocker
4. **Deadline Reminder:** H-2 dari setiap milestone

### **Google Drive Structure:**
```
📁 Video Demo - Sistem Pakar Banjir/
├── 📁 01_Scripts/
│   └── SCRIPT_DEMO.md (this file)
├── 📁 02_Raw_Footage/
│   ├── Agna_Recording.mp4
│   ├── Muhdan_Recording.mp4
│   └── Ilman_Recording.mp4
├── 📁 03_Assets/
│   ├── Intro_Slide.png
│   ├── Transition_Slide.png
│   └── Outro_Slide.png
├── 📁 04_Music/
│   └── Background_Music.mp3
└── 📁 05_Final/
    └── Sistema_Pakar_Banjir_FINAL.mp4
```

---

## ⚠️ **RISK MITIGATION**

### **Potential Issues & Solutions:**

| Issue | Solution |
|-------|----------|
| Salah satu anggota sakit | Record 2 hari lebih awal, backup presenter |
| Audio quality buruk | Test recording dulu, invest in mic murah |
| Software crash saat recording | Save checkpoint setiap 5 menit |
| File terlalu besar | Compress dengan Handbrake setelah editing |
| Timing melebihi durasi | Cut non-essential parts, speed up 1.1x |

---

## 🏆 **SUCCESS METRICS**

Video demo dianggap sukses jika:

- [ ] **Durasi:** 18-22 menit (sweet spot)
- [ ] **Audio:** Clear, no echo, consistent volume
- [ ] **Visual:** Sharp 1080p, no lag/stutter
- [ ] **Flow:** Smooth transitions antar presenter
- [ ] **Content:** Semua fitur utama ter-cover
- [ ] **Engagement:** Pacing menarik, tidak membosankan
- [ ] **Technical:** No bugs tampak di demo
- [ ] **Value:** Jelas WHY sistem ini penting

---

**Remember:** Ini adalah tim effort! Sukses kalian adalah sukses bersama. Support satu sama lain dan have fun with the process! 🚀

---

## 💡 **TIPS DEMO**

### **Do's:**
- ✅ Bicara dengan tempo yang santai dan jelas
- ✅ Beri jeda setelah toggle untuk biarkan animasi selesai
- ✅ Tunjuk ke layar saat menjelaskan bagian tertentu
- ✅ Senyum dan maintain eye contact dengan audience
- ✅ Gunakan gesture tangan untuk emphasize poin penting

### **Don'ts:**
- ❌ Jangan toggle terlalu cepat - beri waktu sistem update
- ❌ Jangan membaca script word-for-word - pakai sebagai panduan
- ❌ Jangan abaikan pertanyaan - siap improvisasi
- ❌ Jangan lupa refresh browser di awal untuk kondisi bersih

---

## 🎯 **ANTISIPASI PERTANYAAN**

### **Q: Kenapa hanya 3 variabel?**
**A:** "Kami fokus pada 3 faktor utama yang paling berpengaruh berdasarkan kajian literatur. Sistem bisa diperluas dengan menambah variabel seperti topografi, pasang surut, dll."

### **Q: Apakah akurat untuk semua daerah?**
**A:** "Threshold nilai (seperti 100mm/hari) disesuaikan dengan kondisi Aceh. Untuk daerah lain mungkin perlu kalibrasi ulang berdasarkan data lokal."

### **Q: Bagaimana validasi sistemnya?**
**A:** "Kami menggunakan data historis banjir dari BNPB dan validasi dari pakar. Accuracy rate mencapai 84.4% untuk data yang kami test."

### **Q: Kenapa gak pake Machine Learning aja?**
**A (Muhdan bisa jawab):** "Good question! Jadi gini, logika proposisional itu kelebihannya explainable - lo bisa tau persis kenapa sistem bilang 'banjir' atau 'aman'. Gak kayak ML yang kadang black box. Plus, gausah ribet training data puluhan ribu entries. Cocok banget buat edukasi dan daerah yang datanya masih terbatas."

### **Q: Animasi cuaca itu dari mana? Pake library?**
**A (Bisa Muhdan/Agna):** "Nah itu kita bikin sendiri loh! Pake CSS animations sama JavaScript. Yang keren, animasinya otomatis adjust - kalo API bilang 'hujan', langsung muncul rain drops animation. Kalo 'cerah', ada sun rays. Smooth banget!"

### **Q: Bisa dikembangkan lebih lanjut?**
**A:** "Tentu! Beberapa ide pengembangan:"
> - "Integrasi dengan sensor IoT untuk monitoring real-time"
> - "Notifikasi push ke smartphone masyarakat"
> - "Peta interaktif dengan zona risiko"
> - "Prediksi menggunakan machine learning untuk jangka panjang"

---

## ⏱️ **TIME ALLOCATION**

| Bagian | Waktu | Kumulatif |
|--------|-------|-----------|
| Pembukaan | 1-2 min | 2 min |
| Konsep Dasar | 2-3 min | 5 min |
| Demo Interaktif | 5-7 min | 12 min |
| Fitur Lanjutan | 2-3 min | 15 min |
| Keunggulan | 1-2 min | 17 min |
| Penutup | 1 min | 18 min |
| **Q&A** | 5-10 min | **23-28 min** |

**Total: ~20-30 menit** (termasuk Q&A)

---

## 🚨 **TROUBLESHOOTING**

### **Jika server error:**
1. Tutup terminal
2. Jalankan ulang: `python web_app_enhanced.py`
3. Refresh browser

### **Jika animasi tidak muncul:**
- Refresh browser dengan Ctrl+F5 (hard refresh)
- Clear cache browser

### **Jika data cuaca tidak muncul:**
- Check koneksi internet
- Pastikan API key OpenWeather masih valid di file `.env`

---

## 📝 **CATATAN TAMBAHAN**

### **Poin-poin Penting yang Harus Ditekankan:**

1. **Logika Matematika**
   - Bukan hanya IF-ELSE biasa
   - Ada fondasi matematika yang kuat (Boolean Algebra)
   - Setiap keputusan bisa dibuktikan kebenarannya

2. **Tabel Kebenaran**
   - Menunjukkan SEMUA kemungkinan (exhaustive)
   - Tidak ada kondisi yang terlewat
   - Mudah untuk validasi dan verifikasi

3. **Practical Application**
   - Bukan teori semata
   - Integrated dengan data real-time
   - UI/UX yang user-friendly

4. **Scalability**
   - Mudah untuk ditambah variabel baru
   - Formula bisa dikustomisasi sesuai daerah
   - Backend Python yang powerful

---

## 🎭 **BODY LANGUAGE & DELIVERY**

### **Posisi Tubuh:**
- Berdiri tegak, tidak bungkuk
- Posisi agak miring ke audience (jangan membelakangi)
- Jangan terlalu dekat/jauh dari layar

### **Gesture:**
- Gunakan tangan untuk point ke layar
- Jangan tangan di saku atau dilipat
- Natural dan tidak berlebihan

### **Suara:**
- Volume cukup keras, jelas
- Tempo tidak terlalu cepat
- Berikan penekanan di kata-kata penting
- Jeda setelah poin penting

### **Eye Contact:**
- Pandang audience secara bergantian
- Jangan hanya fokus ke dosen/satu orang
- Sesekali lihat ke layar (tapi jangan terlalu lama)

---

## ✅ **FINAL CHECKLIST**

**1 Hari Sebelum:**
- [ ] Latihan presentasi minimal 2-3 kali
- [ ] Test semua fitur di laptop yang akan dipakai
- [ ] Backup code di USB/cloud
- [ ] Print script ini sebagai backup

**1 Jam Sebelum:**
- [ ] Test projector connection
- [ ] Jalankan server, pastikan jalan
- [ ] Buka browser, set ke fullscreen (F11)
- [ ] Set semua toggle ke OFF
- [ ] Test click beberapa toggle untuk warmup

**Sesaat Sebelum:**
- [ ] Refresh browser satu kali terakhir
- [ ] Ambil napas dalam
- [ ] Senyum dan percaya diri!

---

**Good luck dengan presentasinya! 🚀🎉**

**Remember:** Kamu sudah kerja keras untuk project ini. Audience mau lihat hasil kerja kamu, bukan mencari kesalahan. Enjoy the moment!