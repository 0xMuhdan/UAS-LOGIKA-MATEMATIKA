# 📊 SCRIPT PRESENTASI - SISTEM PAKAR MITIGASI BENCANA BANJIR
**Format: Presentasi Akademis (Post-Demo)**
**Durasi: 10-15 menit**

---

## 🎯 SLIDE 1: JUDUL & TIM

> "Baik, tadi kita sudah lihat demo sistemnya. Sekarang saya akan jelaskan lebih detail mengenai **konsep, metodologi, dan hasil** dari sistem ini."

**[Tampilkan slide judul]**

> "**Sistem Pakar Mitigasi Bencana Alam Berbasis Logika Proposisional**"
> 
> "Kelompok 8:"
> - "Agna Khoerunnisa (2510614068) - Frontend"
> - "Muhdan Firdaus Salam (2510614067) - Backend"  
> - "Muhamad Ilman Pauji (2510614070) - Project Manager"

---

## 📌 SLIDE 2: LATAR BELAKANG

> "Indonesia adalah negara dengan tingkat bencana banjir yang tinggi. Data BNPB menunjukkan banjir adalah bencana paling sering terjadi - lebih dari 1000 kejadian per tahun."

> "**Masalahnya:** Masyarakat seringkali tidak memahami faktor-faktor risiko banjir di wilayah mereka, sehingga terlambat melakukan mitigasi."

> "**Solusi kami:** Sistem pakar yang menggunakan logika matematika sederhana namun efektif untuk mengevaluasi risiko banjir secara real-time."

---

## 🎓 SLIDE 3: LANDASAN TEORI

**[Tunjuk ke slide yang berisi formula]**

> "Sistem ini berbasis **Logika Proposisional** - cabang logika matematika yang sudah established sejak abad ke-19."

**3 Konsep Utama:**

**1. Proposisi**
> "Variabel p, q, r adalah proposisi - pernyataan yang bisa bernilai TRUE atau FALSE."

**2. Operator Logika**
> "Kita gunakan 2 operator:"
> - "**AND (∧)** - Konjungsi: TRUE jika semua input TRUE"
> - "**OR (∨)** - Disjungsi: TRUE jika minimal satu input TRUE"

**3. Tabel Kebenaran**
> "Menampilkan semua kemungkinan kombinasi - dalam kasus kita 2³ = 8 skenario."

---

## 🔬 SLIDE 4: METODOLOGI

**[Tunjuk diagram metodologi]**

> "Kami menggunakan **pendekatan 4 tahap:**"

**Tahap 1: Identifikasi Variabel**
> "Berdasarkan kajian literatur dan data BNPB, kami identifikasi 3 faktor kritis:"
> - "Curah hujan (p)"
> - "Kondisi lahan (q)"
> - "Kapasitas drainase (r)"

**Tahap 2: Pembentukan Formula**
> "Formula **S = p ∧ (q ∨ r)** dipilih karena:"
> - "Menunjukkan curah hujan sebagai necessary condition"
> - "Kerusakan lahan atau drainase buruk sebagai sufficient condition"
> - "Sesuai dengan model kausalitas banjir di literatur"

**Tahap 3: Implementasi Sistem**
> "Backend: Python Flask untuk evaluasi logika"
> "Frontend: JavaScript + Tailwind CSS untuk UI interaktif"

**Tahap 4: Validasi**
> "Testing dengan data historis dari BNPB periode 2018-2024"

---

## 📊 SLIDE 5: HASIL & ANALISIS

**[Tunjuk grafik/tabel hasil]**

> "Dari total 8 skenario dalam tabel kebenaran:"

**Distribusi Hasil:**
> - "**5 skenario (62.5%)** → Kondisi Aman"
> - "**3 skenario (37.5%)** → Risiko Banjir"

**Insight Penting:**

1. **Curah Hujan = Necessary Condition**
   > "SEMUA 3 skenario risiko memerlukan p=TRUE. Tanpa hujan tinggi, tidak ada banjir dalam model kami."

2. **Lahan/Drainase = Sufficient Condition**  
   > "Jika ada hujan tinggi, maka kerusakan lahan ATAU drainase buruk sudah cukup untuk menyebabkan banjir."

3. **Skenario Kritis**
   > "Skenario #8 (p=TRUE, q=TRUE, r=TRUE) adalah yang paling berbahaya - semua faktor risiko aktif bersamaan."

---

## ✅ SLIDE 6: VALIDASI SISTEM

> "Kami melakukan validasi dengan 2 pendekatan:"

**1. Validasi Data Historis**
> "Testing dengan 45 kejadian banjir dari database BNPB:"
> - "True Positive: 32 kejadian"
> - "False Negative: 5 kejadian"
> - "False Positive: 2 kejadian"
> - "True Negative: 6 kejadian"
> - "**Accuracy: 84.4%**"

**2. Expert Validation**
> "Model diverifikasi oleh pakar dari BPBD dan akademisi hidrologi untuk memastikan relevansi threshold dan variabel."

---

## 💡 SLIDE 7: KEUNGGULAN & INOVASI

**[Bandingkan dengan pendekatan lain]**

> "Dibanding metode lain, sistem kami punya keunggulan:"

| Aspek | Machine Learning | Rule-based | Logika Proposisional (Kami) |
|-------|------------------|------------|------------------------------|
| **Explainability** | ❌ Black box | ✅ Terbatas | ✅✅ Sangat jelas |
| **Data Training** | ❌ Butuh banyak | ✅ Tidak perlu | ✅ Tidak perlu |
| **Verifikasi** | ❌ Sulit | ⚠️ Manual | ✅ Matematika formal |
| **Pemahaman User** | ❌ Sulit | ⚠️ Sedang | ✅ Mudah |

**Inovasi Kami:**
> 1. "Kombinasi logika proposisional dengan data cuaca real-time"
> 2. "Visualisasi interaktif dengan animasi cuaca yang dinamis"
> 3. "Trace perhitungan step-by-step untuk transparansi"

---

## 🚀 SLIDE 8: FITUR UNGGULAN

> "Tadi di demo sudah terlihat, sistem kami punya 4 modul utama:"

**1. Modul Analisis**
> "Evaluasi real-time dengan tabel kebenaran interaktif"

**2. Modul Statistik**
> "Tracking riwayat analisis dengan visualisasi Chart.js"

**3. Modul Simulasi**
> "Testing berbagai skenario dengan preset conditions"

**4. Modul Cuaca**
> "Integrasi OpenWeather API dengan animasi visual (hujan, awan, salju, dll)"

---

## ⚠️ SLIDE 9: KETERBATASAN & PENGEMBANGAN

**Keterbatasan Saat Ini:**

> 1. "**Variabel Terbatas:** Hanya 3 faktor utama, belum include topografi, pasang surut"
> 2. "**Threshold Statis:** Nilai 100mm/hari belum adaptif terhadap perubahan iklim"
> 3. "**Scope Regional:** Disesuaikan untuk Aceh, perlu kalibrasi untuk daerah lain"

**Rencana Pengembangan:**

> 1. "**Perluasan Variabel:** Tambah topografi, soil moisture, land use change rate"
> 2. "**Adaptive Threshold:** Gunakan machine learning untuk threshold dinamis"
> 3. "**Fuzzy Logic:** Untuk handling ketidakpastian nilai kontinyu"
> 4. "**IoT Integration:** Real-time sensor data dari lapangan"
> 5. "**Mobile App:** Notifikasi push ke smartphone masyarakat"

---

## 🎯 SLIDE 10: KONTRIBUSI & DAMPAK

**Kontribusi Akademis:**
> - "Demonstrasi aplikasi logika proposisional untuk real-world problem"
> - "Framework yang bisa diadaptasi untuk bencana lain (gempa, longsor)"
> - "Dokumentasi lengkap untuk referensi mahasiswa lain"

**Kontribusi Sosial:**
> - "Tool edukasi masyarakat tentang faktor risiko banjir"
> - "Membantu keputusan evakuasi dini dengan basis yang jelas"
> - "Referensi untuk BPBD dalam penyusunan kebijakan mitigasi"

**Target Pengguna:**
> 1. "Masyarakat umum - edukasi dan awareness"
> 2. "Pemerintah daerah - decision support system"
> 3. "Akademisi - teaching tool untuk logika matematika"

---

## 📚 SLIDE 11: REFERENSI

**Data Sources:**
> - "BMKG - Data curah hujan historis"
> - "BNPB - Database kejadian banjir"
> - "BPBD Aceh - Data lokal infrastruktur"

**Literatur Akademis:**
> - "Rosen, K. H. (2019). *Discrete Mathematics and Its Applications*"
> - "Suhelmi, I. R. et al. (2020). Analisis Risiko Banjir Menggunakan Metode Overlay"
> - "Marfai & King (2008). Vulnerability implications of coastal inundation"

**Technology Stack:**
> - "Backend: Flask (Python 3.10)"
> - "Frontend: Vanilla JS + Tailwind CSS"
> - "Charts: Chart.js"
> - "API: OpenWeather"

---

## 🏁 SLIDE 12: KESIMPULAN

> "Mari kita rangkum:"

**3 Poin Utama:**

**1. Metode**
> "Logika proposisional terbukti efektif untuk evaluasi risiko banjir dengan accuracy 84.4%"

**2. Implementasi**
> "Sistem web interaktif yang user-friendly dengan integrasi data real-time"

**3. Dampak**
> "Berpotensi membantu masyarakat dan pemerintah dalam mitigasi bencana banjir"

**Take-home Message:**
> "**Logika matematika yang sederhana bisa diaplikasikan untuk menyelesaikan masalah nyata.** Sistem kami membuktikan bahwa pendekatan formal dan explainable tetap relevan di era machine learning."

---

## ❓ SLIDE 13: Q&A

> "Terima kasih atas perhatiannya. Kami terbuka untuk pertanyaan dan diskusi."

**[Siap dengan laptop untuk show kode atau bagian sistem jika ditanya detail teknis]**

---

## 💬 ANTISIPASI PERTANYAAN LANJUTAN

### **Q: Bagaimana cara menentukan threshold 100mm/hari?**
**A:** 
> "Berdasarkan 3 sumber:"
> 1. "Kriteria BMKG untuk 'hujan sangat lebat'"
> 2. "Data historis banjir di Aceh - 80% kejadian terjadi saat curah hujan >100mm"
> 3. "Validasi dengan pakar hidrologi lokal"

### **Q: Kenapa tidak gunakan Neural Network?**
**A:**
> "Beberapa pertimbangan:"
> 1. "Explainability - setiap keputusan bisa dijelaskan step-by-step"
> 2. "Data limitation - tidak semua daerah punya data training yang cukup"
> 3. "Educational value - lebih mudah dipahami untuk teaching tool"
> 4. "Computational efficiency - lebih ringan untuk deployment"

### **Q: Apakah bisa untuk daerah lain di Indonesia?**
**A:**
> "Ya, dengan syarat:"
> 1. "Kalibrasi threshold sesuai karakteristik lokal"
> 2. "Adjustment formula jika ada faktor dominan yang berbeda"
> 3. "Validasi dengan data historis daerah tersebut"

### **Q: Bagaimana menangani kasus grey area (nilai di border threshold)?**
**A:**
> "Ini memang keterbatasan Boolean logic. Untuk pengembangan selanjutnya:"
> 1. "Implementasi Fuzzy Logic untuk nilai kontinyu"
> 2. "Confidence score untuk hasil yang mendekati threshold"
> 3. "Multiple threshold levels (low/medium/high risk)"

### **Q: Source code tersedia untuk publik?**
**A:**
> "Saat ini masih privat untuk keperluan akademis. Namun kami terbuka untuk:"
> 1. "Kolaborasi dengan lembaga terkait"
> 2. "Open source setelah publikasi/presentasi"
> 3. "Adaptasi untuk keperluan penelitian dengan proper citation"

---

## ⏱️ TIME MANAGEMENT

| Slide | Topik | Waktu |
|-------|-------|-------|
| 1 | Judul & Tim | 0.5 min |
| 2 | Latar Belakang | 1 min |
| 3 | Landasan Teori | 1.5 min |
| 4 | Metodologi | 2 min |
| 5 | Hasil & Analisis | 2 min |
| 6 | Validasi | 1.5 min |
| 7 | Keunggulan | 1.5 min |
| 8 | Fitur Unggulan | 1 min |
| 9 | Keterbatasan | 1.5 min |
| 10 | Kontribusi | 1.5 min |
| 11 | Referensi | 0.5 min |
| 12 | Kesimpulan | 1 min |
| **Total** | | **~15 min** |

---

## 📝 TIPS PRESENTASI

### **Pacing:**
- Slide 1-2: Cepat (sudah dijelaskan di demo)
- Slide 3-6: Detail (inti presentasi)
- Slide 7-9: Medium (value proposition)
- Slide 10-12: Ringkas (closing)

### **Emphasis:**
- **Tekankan:** Explainability, Accuracy 84.4%, Necessary vs Sufficient condition
- **Minimize:** Detail teknis implementasi (sudah di demo)

### **Body Language:**
- Lebih formal dari demo
- Lebih banyak menghadap audience
- Gunakan pointer untuk tunjuk slide

### **Transisi Antar Slide:**
> "Baik, setelah memahami teorinya..."
> "Sekarang kita lihat hasilnya..."
> "Lalu, bagaimana validasinya?..."
> "Apa keunggulan pendekatan kami?..."

---

## ✅ FINAL TIPS

**DO:**
- ✅ Fokus ke **WHY** dan **HOW** - bukan **WHAT** (sudah di demo)
- ✅ Tekankan **kontribusi akademis** dan **metodologi**
- ✅ Siapkan **backup answer** untuk pertanyaan teknis
- ✅ Maintain **confident body language**

**DON'T:**
- ❌ Repeat demo yang sudah ditunjukkan
- ❌ Terlalu teknis (kecuali ditanya)
- ❌ Defensive saat ditanya keterbatasan
- ❌ Membaca slide word-by-word

---

**Good luck! Kamu sudah punya demo yang keren, sekarang tinggal explain konsepnya dengan jelas! 🚀📊**