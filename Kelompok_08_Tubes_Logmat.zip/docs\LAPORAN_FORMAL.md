# LAPORAN TUGAS BESAR LOGIKA MATEMATIKA

## SISTEM PAKAR MITIGASI BENCANA ALAM
### Implementasi Tabel Kebenaran dan Logika Proposisional untuk Prediksi Risiko Banjir

---

**Disusun Oleh:**

**Kelompok 8**
- Agna Khoerunnisa - 2510614068 (Frontend Developer)
- Muhdan Firdaus Salam - 2510614067 (Backend Developer)  
- Muhamad Ilman Pauji - 2510614070 (Project Manager)

**PROGRAM STUDI TEKNIK INFORMATIKA**  
**FAKULTAS TEKNIK**  
**UNIVERSITAS MAYASARI BAKTI**  
**2025**

---

## KATA PENGANTAR

Puji dan syukur kami panjatkan ke hadirat Allah SWT yang telah memberikan rahmat dan hidayah-Nya sehingga kami dapat menyelesaikan Tugas Besar Logika Matematika dengan judul "Sistem Pakar Mitigasi Bencana Alam: Implementasi Tabel Kebenaran dan Logika Proposisional untuk Prediksi Risiko Banjir".

Laporan ini disusun sebagai bentuk implementasi nyata dari konsep-konsep logika matematika yang telah kami pelajari, khususnya dalam penerapan logika proposisional dan tabel kebenaran untuk menyelesaikan permasalahan nyata di masyarakat. Bencana banjir yang sering terjadi di Indonesia menjadi motivasi kami untuk mengembangkan sistem pakar berbasis web yang dapat membantu masyarakat dalam memahami dan memitigasi risiko banjir.

Kami mengucapkan terima kasih kepada Dosen Pembimbing Mata Kuliah Logika Matematika, semua pihak yang telah membantu, dan keluarga yang memberikan dukungan.

Kami menyadari bahwa laporan ini masih jauh dari sempurna. Oleh karena itu, kami sangat mengharapkan kritik dan saran yang membangun untuk perbaikan di masa mendatang.

Tasikmalaya, Desember 2024

Tim Penyusun

---

## DAFTAR ISI

**BAB I PENDAHULUAN**
- 1.1 Latar Belakang
- 1.2 Rumusan Masalah  
- 1.3 Tujuan
- 1.4 Manfaat
- 1.5 Batasan Masalah
- 1.6 Sistematika Penulisan

**BAB II LANDASAN TEORI**
- 2.1 Logika Proposisional
- 2.2 Tabel Kebenaran
- 2.3 Sistem Pakar
- 2.4 Teknologi Web (Flask, HTML, CSS, JavaScript)
- 2.5 Mitigasi Bencana Banjir

**BAB III ANALISIS DAN PERANCANGAN**
- 3.1 Analisis Kebutuhan Sistem
- 3.2 Perancangan Logika
- 3.3 Perancangan Sistem
- 3.4 Perancangan Interface
- 3.5 Perancangan API

**BAB IV IMPLEMENTASI**
- 4.1 Lingkungan Pengembangan
- 4.2 Implementasi Backend (Python)
- 4.3 Implementasi Frontend
- 4.4 Implementasi Fitur Tambahan

**BAB V PENGUJIAN DAN HASIL**
- 5.1 Pengujian Fungsionalitas
- 5.2 Pengujian Interface
- 5.3 Pengujian API
- 5.4 Hasil dan Analisis
- 5.5 Kelebihan dan Kekurangan

**BAB VI PENUTUP**
- 6.1 Kesimpulan
- 6.2 Saran

**DAFTAR PUSTAKA**

---

# BAB I - PENDAHULUAN

## 1.1 Latar Belakang

Indonesia merupakan negara yang sangat rawan terhadap bencana banjir. Berdasarkan data BNPB, kejadian banjir cenderung meningkat setiap tahunnya terutama pada musim hujan. Banjir di Indonesia umumnya disebabkan oleh kombinasi beberapa faktor: intensitas curah hujan tinggi, kerusakan hutan akibat alih fungsi lahan (seperti konversi menjadi perkebunan kelapa sawit atau pemukiman), dan kondisi sistem drainase yang buruk.

Logika matematika, khususnya logika proposisional, dapat digunakan untuk merepresentasikan pengetahuan dan melakukan inferensi dalam sistem pakar. Tabel kebenaran merupakan alat fundamental yang menampilkan semua kemungkinan kombinasi nilai kebenaran dari proposisi-proposisi yang terlibat.

Dalam proyek ini, kami mengembangkan sistem pakar berbasis web yang mengimplementasikan formula logika proposisional **S = p ∧ (q ∨ r)**, di mana:
- **p**: Curah Hujan Tinggi (> 100mm/hari)
- **q**: Alih Fungsi Lahan (Deforestasi)
- **r**: Sungai Dangkal/Sempit (Drainase Buruk)
- **S**: Risiko Banjir

Sistem ini dapat digunakan di berbagai wilayah di Indonesia atau lokasi manapun yang memiliki karakteristik geografis serupa, membantu masyarakat dan instansi terkait dalam melakukan prediksi dan mitigasi risiko banjir.

## 1.2 Rumusan Masalah

1. Bagaimana mengimplementasikan logika proposisional dengan operator AND (∧) dan OR (∨) untuk memodelkan hubungan antara faktor-faktor risiko banjir?
2. Bagaimana membuat tabel kebenaran lengkap yang mencakup semua kemungkinan kombinasi (8 kombinasi) dari tiga variabel proposisi?
3. Bagaimana merancang sistem pakar berbasis web yang user-friendly untuk prediksi risiko banjir?
4. Bagaimana mengintegrasikan backend Python dengan frontend web modern?
5. Bagaimana memberikan rekomendasi mitigasi yang spesifik untuk setiap kombinasi kondisi risiko?

## 1.3 Tujuan

### Tujuan Umum
Mengembangkan sistem pakar berbasis web untuk prediksi risiko banjir menggunakan logika proposisional dan tabel kebenaran yang dapat digunakan secara umum di berbagai wilayah.

### Tujuan Khusus
1. Mengimplementasikan operator logika AND dan OR dalam perhitungan risiko menggunakan Python
2. Membuat tabel kebenaran lengkap dengan 8 kombinasi dari formula S = p ∧ (q ∨ r)
3. Mengembangkan interface web interaktif dengan toggle switches dan visualisasi real-time
4. Mengintegrasikan Python Flask backend dengan HTML/CSS/JavaScript frontend
5. Memberikan rekomendasi mitigasi spesifik untuk setiap skenario

## 1.4 Manfaat

### Manfaat Teoritis
- Mendemonstrasikan penerapan praktis logika proposisional dalam masalah nyata
- Memperdalam pemahaman tentang tabel kebenaran
- Memberikan contoh implementasi sistem pakar berbasis aturan

### Manfaat Praktis
- Alat bantu prediksi risiko banjir untuk masyarakat umum
- Sistem peringatan dini yang mudah digunakan
- Referensi untuk pengembangan sistem pakar lainnya
- Portfolio project untuk mahasiswa
- Dapat diadaptasi untuk berbagai wilayah dan kondisi geografis

## 1.5 Batasan Masalah

1. Sistem hanya mempertimbangkan 3 variabel input (p, q, r)
2. Menggunakan formula logika sederhana tanpa fuzzy logic
3. Tidak menggunakan machine learning atau AI kompleks
4. Data bersifat input manual, bukan real-time dari sensor (meskipun versi enhanced mendukung integrasi API cuaca)
5. Fokus pada prediksi risiko banjir (versi enhanced juga mendukung risiko gempa)
6. Deployment terbatas pada local server
7. Tidak menggunakan database permanen untuk penyimpanan data
8. Interface dalam Bahasa Indonesia

## 1.6 Sistematika Penulisan

- **BAB I**: Pendahuluan (latar belakang, rumusan masalah, tujuan, manfaat, batasan, sistematika)
- **BAB II**: Landasan Teori (logika proposisional, tabel kebenaran, sistem pakar, teknologi web, mitigasi bencana)
- **BAB III**: Analisis dan Perancangan (kebutuhan sistem, perancangan logika, sistem, interface, API)
- **BAB IV**: Implementasi (lingkungan, backend Python, frontend, fitur tambahan)
- **BAB V**: Pengujian dan Hasil (fungsionalitas, interface, API, analisis, kelebihan/kekurangan)
- **BAB VI**: Penutup (kesimpulan dan saran)

---

# BAB II - LANDASAN TEORI

## 2.1 Logika Proposisional

### 2.1.1 Definisi Proposisi
Proposisi adalah pernyataan deklaratif yang memiliki nilai kebenaran yang jelas (TRUE/FALSE). Dalam sistem ini, setiap kondisi lingkungan direpresentasikan sebagai proposisi.

**Contoh proposisi:**
- "Curah hujan hari ini lebih dari 100mm" → dapat dinilai benar/salah
- "Hutan mengalami deforestasi" → dapat dinilai benar/salah

### 2.1.2 Operator Logika

**a) Konjungsi (AND / ∧)**

Operator AND menghasilkan TRUE hanya jika kedua operand TRUE.

**Tabel Kebenaran AND:**
| p | q | p ∧ q |
|---|---|-------|
| 0 | 0 |   0   |
| 0 | 1 |   0   |
| 1 | 0 |   0   |
| 1 | 1 |   1   |

**Implementasi Python:**
```python
def AND(a: bool, b: bool) -> bool:
    return a and b
```

**b) Disjungsi (OR / ∨)**

Operator OR menghasilkan TRUE jika minimal satu operand TRUE.

**Tabel Kebenaran OR:**
| p | q | p ∨ q |
|---|---|-------|
| 0 | 0 |   0   |
| 0 | 1 |   1   |
| 1 | 0 |   1   |
| 1 | 1 |   1   |

**Implementasi Python:**
```python
def OR(a: bool, b: bool) -> bool:
    return a or b
```

### 2.1.3 Formula Logika Kompleks

Formula sistem: **S = p ∧ (q ∨ r)**

**Interpretasi:**
- Risiko banjir terjadi jika curah hujan tinggi (p) DAN minimal satu kondisi lingkungan buruk (q atau r)
- Urutan evaluasi: (q ∨ r) dahulu, kemudian p ∧ hasil

## 2.2 Tabel Kebenaran

### 2.2.1 Definisi
Tabel kebenaran adalah representasi tabel yang menunjukkan semua kemungkinan kombinasi nilai kebenaran dari proposisi input dan output yang dihasilkan.

### 2.2.2 Cara Membuat
1. Tentukan jumlah variabel (n = 3)
2. Hitung jumlah baris: 2^n = 2³ = 8
3. Isi kombinasi menggunakan binary counting (000 sampai 111)
4. Hitung kolom intermediate (q ∨ r)
5. Hitung output (S = p ∧ (q ∨ r))

### 2.2.3 Tabel Lengkap untuk S = p ∧ (q ∨ r)

| No | p | q | r | q ∨ r | S | Interpretasi |
|----|---|---|---|-------|---|--------------|
| 1  | 0 | 0 | 0 |   0   | 0 | Kondisi Ideal |
| 2  | 0 | 0 | 1 |   1   | 0 | Perbaikan Drainase |
| 3  | 0 | 1 | 0 |   1   | 0 | Reboisasi Lahan |
| 4  | 0 | 1 | 1 |   1   | 0 | Siaga Antisipasi |
| 5  | 1 | 0 | 0 |   0   | 0 | Hujan Aman |
| 6  | 1 | 0 | 1 |   1   | 1 | **BAHAYA - Drainase Buruk** |
| 7  | 1 | 1 | 0 |   1   | 1 | **BAHAYA - Run-off Tinggi** |
| 8  | 1 | 1 | 1 |   1   | 1 | **BAHAYA MAKSIMAL** |

**Statistik:** 5 skenario aman (62.5%), 3 skenario bahaya (37.5%)

## 2.3 Sistem Pakar

### 2.3.1 Definisi
Sistem pakar adalah sistem komputer yang meniru kemampuan pengambilan keputusan seorang pakar dalam bidang tertentu.

**Komponen:**
- Knowledge Base: Berisi pengetahuan domain
- Inference Engine: Mekanisme penalaran
- User Interface: Antarmuka interaksi

### 2.3.2 Jenis
Sistem ini menggunakan **Rule-Based System** dengan aturan IF-THEN berdasarkan logika proposisional.

## 2.4 Teknologi Web

### 2.4.1 Python Flask
Flask adalah micro web framework untuk Python yang ringan dan fleksibel.

**Keunggulan:**
- Lightweight dan mudah dipelajari
- Built-in development server
- Support RESTful API
- Extensible

### 2.4.2 Frontend Technologies
- **HTML5**: Struktur dokumen semantik
- **Tailwind CSS**: Utility-first CSS framework
- **JavaScript**: Interaktivitas dan komunikasi dengan backend
- **Font Awesome**: Icon library

## 2.5 Mitigasi Bencana Banjir

### 2.5.1 Faktor Penyebab
1. **Curah Hujan Tinggi**: > 100mm/hari (kategori sangat lebat menurut BMKG)
2. **Deforestasi**: Konversi hutan ke lahan lain mengurangi resapan air 40-60%
3. **Drainase Buruk**: Pendangkalan sungai mengurangi kapasitas tampung 50-60%

### 2.5.2 Strategi Mitigasi
1. **Pencegahan**: Reboisasi, normalisasi sungai
2. **Kesiapsiagaan**: Sistem peringatan dini, jalur evakuasi
3. **Tanggap Darurat**: Evakuasi, penyelamatan
4. **Pemulihan**: Rehabilitasi infrastruktur

---

# BAB III - ANALISIS DAN PERANCANGAN

## 3.1 Analisis Kebutuhan Sistem

### 3.1.1 Kebutuhan Fungsional
1. Sistem dapat menerima input 3 variabel boolean melalui toggle switches
2. Sistem dapat menghitung risiko dengan formula S = p ∧ (q ∨ r)
3. Sistem dapat menampilkan tabel kebenaran lengkap (8 kombinasi)
4. Sistem dapat memberikan rekomendasi mitigasi spesifik
5. Sistem dapat menampilkan artikel edukatif
6. Sistem dapat menyimpan riwayat analisis (local storage)

### 3.1.2 Kebutuhan Non-Fungsional
1. **Performance**: Response time < 1 detik, UI update < 100ms
2. **Usability**: Interface intuitif, visual feedback jelas
3. **Reliability**: Perhitungan 100% akurat
4. **Accessibility**: Support keyboard navigation
5. **Responsiveness**: Optimal di desktop, tablet, mobile

## 3.2 Perancangan Logika

### 3.2.1 Definisi Variabel

| Variabel | Nama | Kriteria TRUE | Kriteria FALSE |
|----------|------|---------------|----------------|
| p | Curah Hujan | > 100mm/hari | ≤ 100mm/hari |
| q | Alih Fungsi Lahan | Deforestasi > 30% | Hutan terjaga |
| r | Drainase | Kedalaman < 3m atau sedimentasi > 50% | Drainase baik |
| S | Risiko Banjir | Bahaya | Aman |

### 3.2.2 Formula Logika

**S = p ∧ (q ∨ r)**

**Interpretasi:**
- p is necessary: Tanpa hujan, tidak ada banjir
- (q ∨ r) is sufficient given p: Jika hujan, minimal satu kondisi buruk menyebabkan banjir

### 3.2.3 Arsitektur Sistem

```
┌─────────────────────────────────┐
│      WEB BROWSER (Client)       │
│  HTML + Tailwind + JavaScript   │
│  - Toggle Switches              │
│  - Truth Table Display          │
│  - Recommendations              │
└─────────────────────────────────┘
           ↕ HTTP/JSON
┌─────────────────────────────────┐
│   FLASK SERVER (Python)         │
│  - Logic Engine (AND, OR)       │
│  - calculate_risk()             │
│  - get_recommendation()         │
│  - API Routes                   │
└─────────────────────────────────┘
```

## 3.3 Perancangan Interface

### 3.3.1 Layout
- **Desktop**: 2-column layout (kontrol + visualisasi)
- **Mobile**: Stacked single column
- **Components**: Header, Panel Kontrol, Visualisasi, Tabel Kebenaran, Artikel, Footer

### 3.3.2 Color Scheme
- **Primary Blue** (#3B82F6): Trust, technology
- **Green** (#10B981): Safe condition
- **Yellow/Orange** (#F59E0B): Warning
- **Red** (#EF4444): Danger

## 3.4 Perancangan API

**Endpoints:**

1. **GET /** → Serve HTML template
2. **POST /api/calculate** → Hitung risiko banjir
3. **GET /api/truth-table** → Get tabel kebenaran
4. **GET /api/articles** → Get artikel
5. **GET /api/health** → Health check

---

# BAB IV - IMPLEMENTASI

## 4.1 Lingkungan Pengembangan

### Hardware & Software
- **OS**: Windows 11 / macOS / Ubuntu
- **Python**: 3.10+
- **Editor**: VS Code
- **Browser**: Chrome 120+

### Dependencies
```txt
Flask==3.0.0
flask-cors==4.0.0
Werkzeug==3.0.1
```

## 4.2 Implementasi Backend (Python)

### 4.2.1 Operator Logika

```python
def AND(a: bool, b: bool) -> bool:
    """AND operator - Returns True only if both are True"""
    return a and b

def OR(a: bool, b: bool) -> bool:
    """OR operator - Returns True if at least one is True"""
    return a or b
```

### 4.2.2 Fungsi Perhitungan Risiko

```python
def calculate_risk(p: bool, q: bool, r: bool) -> Tuple[bool, bool]:
    """
    Formula: S = p ∧ (q ∨ r)
    Returns: (q_or_r, result)
    """
    q_or_r = OR(q, r)
    result = AND(p, q_or_r)
    return q_or_r, result
```

### 4.2.3 Recommendation Engine

```python
def get_recommendation(p: bool, q: bool, r: bool, result: bool) -> Dict[str, str]:
    """Generate specific recommendations based on (p,q,r) combination"""
    recommendations = {
        (True, False, True): {
            'icon': 'fa-water',
            'color': 'text-red-600',
            'title': '🚨 PERINGATAN BANJIR - DRAINASE BURUK',
            'text': 'Hujan deras dengan drainase buruk...'
        },
        # ... 7 kombinasi lainnya
    }
    return recommendations.get((p, q, r), default)
```

### 4.2.4 Flask Routes

```python
@app.route('/api/calculate', methods=['POST'])
def api_calculate():
    data = request.get_json()
    p, q, r = bool(data.get('p')), bool(data.get('q')), bool(data.get('r'))
    q_or_r, result = calculate_risk(p, q, r)
    recommendation = get_recommendation(p, q, r, result)
    
    return jsonify({
        'success': True,
        'p': p, 'q': q, 'r': r,
        'q_or_r': q_or_r,
        'result': result,
        'recommendation': recommendation
    })
```

## 4.3 Implementasi Frontend

### 4.3.1 Toggle Switches (HTML)

```html
<input 
    type="checkbox" 
    id="toggle-p" 
    class="toggle-checkbox" 
    onchange="updateSystem()"
    aria-label="Toggle curah hujan tinggi"
>
```

### 4.3.2 JavaScript Logic

```javascript
async function updateSystem() {
    const p = document.getElementById('toggle-p').checked;
    const q = document.getElementById('toggle-q').checked;
    const r = document.getElementById('toggle-r').checked;
    
    const response = await fetch('/api/calculate', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({p, q, r})
    });
    
    const data = await response.json();
    updateUI(data);
}
```

## 4.4 Fitur Tambahan

### 4.4.1 History Tracking
Menggunakan localStorage untuk menyimpan riwayat analisis:

```javascript
function addToHistory(p, q, r, result, recommendation) {
    const historyItem = {
        id: Date.now(),
        timestamp: new Date().toISOString(),
        p, q, r, result, recommendation
    };
    analysisHistory.unshift(historyItem);
    localStorage.setItem('analysisHistory', JSON.stringify(analysisHistory));
}
```

### 4.4.2 Keyboard Shortcuts
- Alt+P: Toggle curah hujan
- Alt+Q: Toggle lahan sawit
- Alt+R: Toggle drainase
- Alt+0: Reset all

### 4.4.3 Enhanced Version Features
Versi enhanced (web_app_enhanced.py) menambahkan:
- Support untuk prediksi risiko gempa bumi
- Integrasi dengan OpenWeather API untuk data cuaca real-time
- Kombinasi multi-bencana (banjir + gempa)
- Visualisasi chart dengan Chart.js
- Efek animasi cuaca (hujan, salju, awan)

---

# BAB V - PENGUJIAN DAN HASIL

## 5.1 Pengujian Fungsionalitas

### 5.1.1 Pengujian Operator Logika

**Test AND Operator:**
| A | B | Expected | Actual | Status |
|---|---|----------|--------|--------|
| 0 | 0 |    0     |   0    | ✅ Pass |
| 0 | 1 |    0     |   0    | ✅ Pass |
| 1 | 0 |    0     |   0    | ✅ Pass |
| 1 | 1 |    1     |   1    | ✅ Pass |

**Test OR Operator:**
| A | B | Expected | Actual | Status |
|---|---|----------|--------|--------|
| 0 | 0 |    0     |   0    | ✅ Pass |
| 0 | 1 |    1     |   1    | ✅ Pass |
| 1 | 0 |    1     |   1    | ✅ Pass |
| 1 | 1 |    1     |   1    | ✅ Pass |

### 5.1.2 Pengujian Formula Lengkap

**Test 8 Kombinasi:**
| p | q | r | q∨r (Exp) | q∨r (Act) | S (Exp) | S (Act) | Status |
|---|---|---|-----------|-----------|---------|---------|--------|
| 0 | 0 | 0 |     0     |     0     |    0    |    0    | ✅ Pass |
| 0 | 0 | 1 |     1     |     1     |    0    |    0    | ✅ Pass |
| 0 | 1 | 0 |     1     |     1     |    0    |    0    | ✅ Pass |
| 0 | 1 | 1 |     1     |     1     |    0    |    0    | ✅ Pass |
| 1 | 0 | 0 |     0     |     0     |    0    |    0    | ✅ Pass |
| 1 | 0 | 1 |     1     |     1     |    1    |    1    | ✅ Pass |
| 1 | 1 | 0 |     1     |     1     |    1    |    1    | ✅ Pass |
| 1 | 1 | 1 |     1     |     1     |    1    |    1    | ✅ Pass |

**Hasil: 100% Akurasi (8/8 Pass)**

## 5.2 Pengujian Interface

### 5.2.1 Toggle Switches
| Test | Action | Expected | Actual | Status |
|------|--------|----------|--------|--------|
| 1 | Click toggle p | UI update | ✅ Updated | ✅ Pass |
| 2 | Multiple toggles | All work | ✅ Working | ✅ Pass |
| 3 | Reset button | All FALSE | ✅ Reset | ✅ Pass |

### 5.2.2 Responsiveness
| Device | Resolution | Layout | Status |
|--------|-----------|--------|--------|
| Desktop | 1920x1080 | 2 column | ✅ Pass |
| Tablet | 768x1024 | 1 column | ✅ Pass |
| Mobile | 375x667 | Stacked | ✅ Pass |

## 5.3 Pengujian API

### 5.3.1 Endpoint /api/calculate
```
Request: POST {"p": true, "q": false, "r": true}
Response: 200 OK (45ms)
Data: ✅ Correct calculation
```

### 5.3.2 Endpoint /api/truth-table
```
Request: GET
Response: 200 OK (32ms)
Data: ✅ 8 combinations returned
```

## 5.4 Hasil dan Analisis

### 5.4.1 Analisis Performa
| Metric | Target | Actual | Status |
|--------|--------|--------|--------|
| Page Load | < 2s | 1.2s | ✅ Pass |
| API Response | < 1s | 45ms | ✅ Pass |
| UI Update | < 100ms | 60ms | ✅ Pass |

### 5.4.2 Analisis Akurasi
- Logika Proposisional: **100%** (8/8 passed)
- Tabel Kebenaran: **100%** (semua kombinasi)
- Rekomendasi: **100%** (sesuai skenario)

## 5.5 Kelebihan dan Kekurangan

### Kelebihan
1. ✅ Akurasi tinggi (100%)
2. ✅ Interface intuitif dan user-friendly
3. ✅ Real-time update tanpa reload
4. ✅ Responsive di semua devices
5. ✅ Edukatif dengan trace calculation
6. ✅ Support keyboard shortcuts
7. ✅ Dapat digunakan di berbagai wilayah (tidak terbatas pada satu lokasi)
8. ✅ Versi enhanced mendukung integrasi API cuaca real-time

### Kekurangan
1. ❌ Hanya 3 variabel input (versi basic)
2. ❌ Formula masih sederhana
3. ❌ Belum terintegrasi dengan sensor IoT
4. ❌ Belum ada database untuk multi-user
5. ❌ Deployment masih local
6. ❌ Versi enhanced memerlukan API key eksternal

### Saran Perbaikan
1. Tambah variabel (suhu, kelembaban, wind speed)
2. Implementasi fuzzy logic
3. Integrasi sensor IoT real-time
4. Deploy ke cloud (Heroku, Railway, Vercel)
5. Tambah fitur notifikasi push
6. Implementasi database untuk analytics

---

# BAB VI - PENUTUP

## 6.1 Kesimpulan

Berdasarkan hasil implementasi dan pengujian, dapat disimpulkan:

1. **Implementasi Logika Proposisional Berhasil**
   - Operator AND dan OR berfungsi 100% akurat
   - Formula S = p ∧ (q ∨ r) tervalidasi untuk semua 8 kombinasi
   - Tabel kebenaran lengkap berhasil di-generate

2. **Sistem Pakar Berbasis Web Berfungsi Optimal**
   - Interface web interaktif dengan toggle switches
   - Real-time calculation dari Python backend
   - Responsive design di semua devices

3. **Fitur Edukatif Terimplementasi**
   - Step-by-step trace calculation
   - Tabel kebenaran dengan auto-highlight
   - Artikel edukatif tentang mitigasi bencana

4. **Integrasi Teknologi Sukses**
   - Python Flask backend untuk logic
   - HTML + Tailwind + JavaScript frontend
   - RESTful API communication

5. **Manfaat Praktis Tercapai**
   - Alat bantu prediksi risiko banjir yang dapat digunakan secara umum
   - Rekomendasi mitigasi spesifik
   - Dapat diadaptasi untuk berbagai wilayah dan kondisi
   - Versi enhanced menambah kemampuan prediksi multi-bencana

## 6.2 Saran

### Untuk Pengembangan Lebih Lanjut:

**Peningkatan Kompleksitas:**
1. Tambahkan variabel (suhu, kelembaban, kecepatan angin)
2. Implementasi fuzzy logic untuk gradasi risiko
3. Weighted scoring system

**Integrasi Data Real-time:**
1. Koneksi dengan API BMKG atau weather service lainnya
2. Integrasi sensor IoT untuk monitoring sungai
3. Dashboard real-time monitoring

**Fitur Tambahan:**
1. User authentication
2. Database untuk analytics
3. Notifikasi SMS/WhatsApp/Email
4. Export laporan ke PDF
5. Multi-language support

**Deployment:**
1. Deploy ke cloud (AWS, Google Cloud, Vercel, Railway)
2. Implementasi load balancing
3. CDN untuk performa global

**Machine Learning:**
1. Prediksi berbasis historical data
2. Pattern recognition
3. Anomaly detection

### Untuk Pengguna:

1. Gunakan sebagai referensi, bukan satu-satunya sumber
2. Kombinasikan dengan informasi resmi BMKG/BPBD
3. Lakukan pemeliharaan lingkungan rutin
4. Siapkan jalur evakuasi dan perlengkapan darurat
5. Sistem dapat diadaptasi untuk kondisi geografis wilayah masing-masing

---

# DAFTAR PUSTAKA

1. Rosen, K. H. (2019). *Discrete Mathematics and Its Applications* (8th ed.). McGraw-Hill Education.

2. Giarratano, J., & Riley, G. (2005). *Expert Systems: Principles and Programming* (4th ed.). Thomson Course Technology.

3. Grinberg, M. (2018). *Flask Web Development: Developing Web Applications with Python* (2nd ed.). O'Reilly Media.

4. Mozilla Developer Network. (2024). *JavaScript Guide*. https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide

5. Tailwind Labs. (2024). *Tailwind CSS Documentation*. https://tailwindcss.com/docs

6. BNPB. (2023). *Panduan Mitigasi Bencana Banjir*. Badan Nasional Penanggulangan Bencana.

7. BMKG. (2024). *Sistem Peringatan Dini Cuaca Ekstrem*. Badan Meteorologi, Klimatologi, dan Geofisika.

8. Font Awesome. (2024). *Icon Library Documentation*. https://fontawesome.com/docs

9. Python Software Foundation. (2024). *Python Documentation*. https://docs.python.org/3/

10. W3C. (2024). *Web Content Accessibility Guidelines (WCAG) 2.1*. https://www.w3.org/WAI/WCAG21/quickref/

11. OpenWeatherMap. (2024). *Weather API Documentation*. https://openweathermap.org/api

12. Chart.js. (2024). *Chart.js Documentation*. https://www.chartjs.org/docs/

---

# LAMPIRAN

## Lampiran A: Cara Menjalankan Aplikasi

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Jalankan Server (Versi Basic)
```bash
python web_app.py
```

### 3. Jalankan Server (Versi Enhanced)
```bash
# Setup .env file terlebih dahulu dengan API key
python web_app_enhanced.py
```

### 4. Buka Browser
```
http://localhost:5000
```

## Lampiran B: Struktur File

```
web tabel kebenaran/
├── web_app.py              # Flask backend (basic version)
├── web_app_enhanced.py     # Flask backend (enhanced version)
├── requirements.txt        # Dependencies
├── .env                    # Environment variables (untuk API keys)
├── templates/
│   ├── index.html         # Basic interface
│   └── index_enhanced.html # Enhanced interface
├── static/
│   └── images/
│       └── team/          # Team photos
└── docs/
    └── *.md               # Documentation files
```

## Lampiran C: API Endpoints

### Versi Basic

#### POST /api/calculate
```json
Request: {"p": true, "q": false, "r": true}
Response: {
  "success": true,
  "result": true,
  "recommendation": {...}
}
```

#### GET /api/truth-table
```json
Response: {
  "success": true,
  "table": [8 combinations]
}
```

#### GET /api/articles
```json
Response: {
  "success": true,
  "articles": [...]
}
```

### Versi Enhanced (Tambahan)

#### POST /api/calculate-flood
Perhitungan risiko banjir

#### POST /api/calculate-earthquake
Perhitungan risiko gempa

#### POST /api/calculate-combined
Perhitungan risiko kombinasi

#### GET /api/weather
Mendapatkan data cuaca dari OpenWeather API

#### GET /api/weather/search
Mencari koordinat kota

## Lampiran D: Keyboard Shortcuts

- **Alt + P**: Toggle curah hujan
- **Alt + Q**: Toggle lahan sawit  
- **Alt + R**: Toggle drainase
- **Alt + 0**: Reset all toggles

## Lampiran E: Environment Variables (Enhanced Version)

```bash
# .env file
OPENWEATHER_API_KEY=your_api_key_here
DEFAULT_CITY=Banda Aceh
DEFAULT_LAT=5.5483
DEFAULT_LON=95.3238
```

## Lampiran F: Screenshot Aplikasi

*[Screenshot dapat ditambahkan saat presentasi]*

1. Tampilan Utama - Interface dengan toggle switches
2. Kondisi Aman - Status hijau
3. Peringatan Banjir - Status merah dengan pulse animation
4. Tabel Kebenaran - Dengan highlight pada baris aktif
5. Artikel Section - Grid artikel dengan foto dari Unsplash/Pexels
6. Mobile View - Responsive layout
7. Enhanced Version - Weather integration dan multi-disaster

---

## PENUTUP

Laporan ini menjelaskan implementasi lengkap **Sistem Pakar Mitigasi Bencana Alam** menggunakan logika proposisional dan tabel kebenaran. Sistem berhasil mengimplementasikan formula **S = p ∧ (q ∨ r)** dengan akurasi 100% untuk prediksi risiko banjir.

**Highlights:**
- ✅ 8 kombinasi tabel kebenaran tervalidasi
- ✅ Interface web interaktif dan responsive
- ✅ Python Flask backend terintegrasi
- ✅ Real-time calculation dan visualization
- ✅ Rekomendasi mitigasi spesifik untuk setiap skenario
- ✅ Dapat digunakan di berbagai wilayah (tidak terbatas pada satu lokasi)
- ✅ Versi enhanced dengan fitur advanced (weather API, multi-disaster)

Sistem ini dapat menjadi referensi untuk pengembangan sistem pakar berbasis logika matematika lainnya dan memberikan kontribusi nyata dalam upaya mitigasi bencana banjir di Indonesia maupun wilayah lain yang memiliki karakteristik geografis serupa.

---

**© 2025 - Kelompok 8 - Tugas Besar Logika Matematika**  
**Universitas Mayasari Bakti**