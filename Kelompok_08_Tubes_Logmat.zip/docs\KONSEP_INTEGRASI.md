# Dokumentasi Integrasi: Tabel Kebenaran & Logika Proposisional

## 📚 Pengantar

Dokumen ini menjelaskan bagaimana **Tabel Kebenaran** dan **Logika Proposisional** bekerja bersama dalam sistem keputusan otomatis untuk kelompok 3-4 orang.

---

## 🎯 Konsep Dasar

### 1. Logika Proposisional
**Logika Proposisional** adalah cabang logika yang mempelajari proposisi (pernyataan yang bernilai benar atau salah) dan hubungan antar proposisi menggunakan operator logika.

**Operator Logika yang Digunakan:**
- **AND (∧)** - Konjungsi: Benar jika semua proposisi benar
- **OR (∨)** - Disjungsi: Benar jika minimal satu proposisi benar
- **NOT (¬)** - Negasi: Membalik nilai kebenaran
- **XOR (⊕)** - Exclusive OR: Benar jika jumlah proposisi benar ganjil
- **NAND** - Not AND: Kebalikan dari AND
- **NOR** - Not OR: Kebalikan dari OR

### 2. Tabel Kebenaran
**Tabel Kebenaran** adalah representasi visual yang menunjukkan semua kemungkinan kombinasi nilai input dan output yang dihasilkan dari operasi logika.

**Komponen Tabel Kebenaran:**
- **Input Columns**: Semua kemungkinan kombinasi nilai True/False untuk setiap proposisi
- **Output Column**: Hasil operasi logika berdasarkan kombinasi input

---

## 🔗 Integrasi dalam Sistem Keputusan Kelompok

### Skenario: Keputusan untuk 3-4 Orang

Misalkan ada 3 orang (A, B, C) yang harus membuat keputusan bersama.

#### **Contoh 1: Sistem Voting Mayoritas (OR Logic)**

**Proposisi:**
- A = "Orang A setuju"
- B = "Orang B setuju"
- C = "Orang C setuju"

**Rumus Logika:** `A OR B OR C`

**Tabel Kebenaran:**

| A | B | C | Hasil (A ∨ B ∨ C) | Keputusan |
|---|---|---|-------------------|-----------|
| F | F | F | **F** | ❌ Ditolak |
| F | F | T | **T** | ✅ Disetujui |
| F | T | F | **T** | ✅ Disetujui |
| F | T | T | **T** | ✅ Disetujui |
| T | F | F | **T** | ✅ Disetujui |
| T | F | T | **T** | ✅ Disetujui |
| T | T | F | **T** | ✅ Disetujui |
| T | T | T | **T** | ✅ Disetujui |

**Interpretasi:** Keputusan disetujui jika **minimal 1 orang** setuju.

---

#### **Contoh 2: Sistem Unanimous (AND Logic)**

**Rumus Logika:** `A AND B AND C`

**Tabel Kebenaran:**

| A | B | C | Hasil (A ∧ B ∧ C) | Keputusan |
|---|---|---|-------------------|-----------|
| F | F | F | **F** | ❌ Ditolak |
| F | F | T | **F** | ❌ Ditolak |
| F | T | F | **F** | ❌ Ditolak |
| F | T | T | **F** | ❌ Ditolak |
| T | F | F | **F** | ❌ Ditolak |
| T | F | T | **F** | ❌ Ditolak |
| T | T | F | **F** | ❌ Ditolak |
| T | T | T | **T** | ✅ Disetujui |

**Interpretasi:** Keputusan disetujui hanya jika **semua orang** setuju.

---

#### **Contoh 3: Sistem Mayoritas Sederhana (Custom Logic)**

**Rumus Logika:** `(A AND B) OR (A AND C) OR (B AND C)`

**Tabel Kebenaran:**

| A | B | C | A∧B | A∧C | B∧C | Hasil | Keputusan |
|---|---|---|-----|-----|-----|-------|-----------|
| F | F | F | F | F | F | **F** | ❌ Ditolak |
| F | F | T | F | F | F | **F** | ❌ Ditolak |
| F | T | F | F | F | F | **F** | ❌ Ditolak |
| F | T | T | F | F | T | **T** | ✅ Disetujui |
| T | F | F | F | F | F | **F** | ❌ Ditolak |
| T | F | T | F | T | F | **T** | ✅ Disetujui |
| T | T | F | T | F | F | **T** | ✅ Disetujui |
| T | T | T | T | T | T | **T** | ✅ Disetujui |

**Interpretasi:** Keputusan disetujui jika **minimal 2 dari 3 orang** setuju.

---

#### **Contoh 4: Untuk 4 Orang - Mayoritas Mutlak**

**Proposisi:** A, B, C, D (4 orang)

**Rumus Logika:** `(A AND B AND C) OR (A AND B AND D) OR (A AND C AND D) OR (B AND C AND D)`

**Tabel Kebenaran (16 kombinasi):**

| A | B | C | D | Jumlah Setuju | Hasil | Keputusan |
|---|---|---|---|---------------|-------|-----------|
| F | F | F | F | 0 | **F** | ❌ Ditolak |
| F | F | F | T | 1 | **F** | ❌ Ditolak |
| F | F | T | F | 1 | **F** | ❌ Ditolak |
| F | F | T | T | 2 | **F** | ❌ Ditolak |
| F | T | F | F | 1 | **F** | ❌ Ditolak |
| F | T | F | T | 2 | **F** | ❌ Ditolak |
| F | T | T | F | 2 | **F** | ❌ Ditolak |
| F | T | T | T | 3 | **T** | ✅ Disetujui |
| T | F | F | F | 1 | **F** | ❌ Ditolak |
| T | F | F | T | 2 | **F** | ❌ Ditolak |
| T | F | T | F | 2 | **F** | ❌ Ditolak |
| T | F | T | T | 3 | **T** | ✅ Disetujui |
| T | T | F | F | 2 | **F** | ❌ Ditolak |
| T | T | F | T | 3 | **T** | ✅ Disetujui |
| T | T | T | F | 3 | **T** | ✅ Disetujui |
| T | T | T | T | 4 | **T** | ✅ Disetujui |

**Interpretasi:** Keputusan disetujui jika **minimal 3 dari 4 orang** setuju.

---

## 💡 Bagaimana Keduanya Bekerja Bersama?

### Alur Kerja Sistem:

```
┌─────────────────────────────────────────────────────────────┐
│  1. INPUT: User memasukkan nilai proposisi (A, B, C, D)    │
│     Contoh: A=True, B=True, C=False, D=True                 │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│  2. LOGIKA PROPOSISIONAL: Sistem menerapkan rumus logika   │
│     Contoh: (A AND B AND C) OR (A AND B AND D) OR ...       │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│  3. TABEL KEBENARAN: Sistem mencari baris yang sesuai      │
│     dengan kombinasi input di tabel kebenaran               │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│  4. OUTPUT: Sistem menampilkan hasil keputusan              │
│     Contoh: "Disetujui" (karena 3 dari 4 orang setuju)      │
└─────────────────────────────────────────────────────────────┘
```

### Keuntungan Integrasi:

1. **Transparansi**
   - Setiap keputusan dapat ditelusuri melalui tabel kebenaran
   - User dapat melihat semua kemungkinan hasil

2. **Fleksibilitas**
   - Dapat mengubah rumus logika sesuai kebutuhan
   - Mendukung berbagai sistem voting (unanimous, mayoritas, dll)

3. **Otomasi**
   - Sistem secara otomatis menghitung hasil
   - Mengurangi kesalahan manual

4. **Edukatif**
   - User memahami dasar logika di balik keputusan
   - Visualisasi yang jelas melalui tabel

---

## 🛠️ Implementasi dalam Kode Python

### Contoh Fungsi untuk 3 Orang (Mayoritas):

```python
def keputusan_mayoritas_3_orang(a, b, c):
    """
    Sistem keputusan mayoritas untuk 3 orang.
    Disetujui jika minimal 2 orang setuju.
    
    Args:
        a, b, c: Boolean (True/False) untuk setiap orang
    
    Returns:
        Boolean: True jika disetujui, False jika ditolak
    """
    # Rumus logika: (A AND B) OR (A AND C) OR (B AND C)
    hasil = (a and b) or (a and c) or (b and c)
    return hasil

# Contoh penggunaan:
print(keputusan_mayoritas_3_orang(True, True, False))   # True (2 setuju)
print(keputusan_mayoritas_3_orang(True, False, False))  # False (1 setuju)
```

### Contoh Fungsi untuk 4 Orang (Mayoritas Mutlak):

```python
def keputusan_mayoritas_4_orang(a, b, c, d):
    """
    Sistem keputusan mayoritas mutlak untuk 4 orang.
    Disetujui jika minimal 3 orang setuju.
    
    Args:
        a, b, c, d: Boolean (True/False) untuk setiap orang
    
    Returns:
        Boolean: True jika disetujui, False jika ditolak
    """
    # Hitung jumlah yang setuju
    jumlah_setuju = sum([a, b, c, d])
    
    # Disetujui jika >= 3 orang setuju
    hasil = jumlah_setuju >= 3
    return hasil

# Contoh penggunaan:
print(keputusan_mayoritas_4_orang(True, True, True, False))   # True (3 setuju)
print(keputusan_mayoritas_4_orang(True, True, False, False))  # False (2 setuju)
```

### Fungsi Generate Tabel Kebenaran:

```python
from itertools import product

def generate_truth_table(num_variables, logic_function):
    """
    Generate tabel kebenaran untuk sejumlah variabel.
    
    Args:
        num_variables: Jumlah variabel (3 atau 4)
        logic_function: Fungsi logika yang akan dievaluasi
    
    Returns:
        List of tuples: (input_combination, output)
    """
    # Generate semua kombinasi True/False
    combinations = list(product([False, True], repeat=num_variables))
    
    # Buat tabel kebenaran
    truth_table = []
    for combo in combinations:
        output = logic_function(*combo)
        truth_table.append((*combo, output))
    
    return truth_table

# Contoh penggunaan:
tabel_3_orang = generate_truth_table(3, keputusan_mayoritas_3_orang)
print("Tabel Kebenaran untuk 3 Orang (Mayoritas):")
print("A\tB\tC\tHasil")
for row in tabel_3_orang:
    print(f"{row[0]}\t{row[1]}\t{row[2]}\t{row[3]}")
```

---

## 📊 Visualisasi dalam Web Interface

### Tampilan yang Disarankan:

```
┌──────────────────────────────────────────────────────────┐
│                    SISTEM KEPUTUSAN                      │
├──────────────────────────────────────────────────────────┤
│                                                          │
│  Pilih Jumlah Orang: ○ 3 Orang  ● 4 Orang              │
│                                                          │
│  Pilih Sistem:                                          │
│  ○ Unanimous (Semua harus setuju)                       │
│  ● Mayoritas (Minimal 50%+1)                            │
│  ○ Mayoritas Mutlak (Minimal 75%)                       │
│  ○ Minimal 1 Orang                                      │
│                                                          │
├──────────────────────────────────────────────────────────┤
│                    INPUT PROPOSISI                       │
├──────────────────────────────────────────────────────────┤
│                                                          │
│  Orang A: ☑ Setuju  ☐ Tidak Setuju                     │
│  Orang B: ☑ Setuju  ☐ Tidak Setuju                     │
│  Orang C: ☐ Setuju  ☑ Tidak Setuju                     │
│  Orang D: ☑ Setuju  ☐ Tidak Setuju                     │
│                                                          │
│         [HITUNG HASIL]                                   │
│                                                          │
├──────────────────────────────────────────────────────────┤
│                       HASIL                              │
├──────────────────────────────────────────────────────────┤
│                                                          │
│  Rumus Logika:                                          │
│  (A ∧ B ∧ C) ∨ (A ∧ B ∧ D) ∨ (A ∧ C ∧ D) ∨ (B ∧ C ∧ D) │
│                                                          │
│  Jumlah Setuju: 3 dari 4 orang                          │
│                                                          │
│  ✅ KEPUTUSAN DISETUJUI                                 │
│                                                          │
├──────────────────────────────────────────────────────────┤
│              TABEL KEBENARAN LENGKAP                     │
├──────────────────────────────────────────────────────────┤
│                                                          │
│  [Tampilkan tabel kebenaran dengan highlight pada       │
│   baris yang sesuai dengan input saat ini]              │
│                                                          │
└──────────────────────────────────────────────────────────┘
```

---

## 🎓 Penjelasan Edukatif

### Mengapa Menggunakan Tabel Kebenaran?

1. **Kelengkapan**: Menampilkan semua kemungkinan hasil
2. **Verifikasi**: Memastikan logika bekerja dengan benar
3. **Debugging**: Mudah menemukan kesalahan dalam rumus logika
4. **Pembelajaran**: Membantu memahami hubungan antar proposisi

### Kapan Menggunakan Operator Logika Tertentu?

| Operator | Use Case | Contoh Aplikasi |
|----------|----------|-----------------|
| AND | Semua kondisi harus terpenuhi | Unanimous voting, validasi form |
| OR | Minimal satu kondisi terpenuhi | Flexible approval, search filters |
| XOR | Tepat satu kondisi terpenuhi | Toggle states, exclusive options |
| NAND | Tidak semua kondisi terpenuhi | Rejection criteria |
| NOR | Tidak ada kondisi terpenuhi | Default case, fallback |

---

## 🚀 Pengembangan Lebih Lanjut

### Fitur yang Bisa Ditambahkan:

1. **Weighted Voting**
   - Setiap orang memiliki bobot suara berbeda
   - Contoh: A=2 votes, B=1 vote, C=1 vote

2. **Conditional Logic**
   - Keputusan bergantung pada kondisi tertentu
   - Contoh: "Jika A setuju, maka minimal 1 dari B/C harus setuju"

3. **History & Analytics**
   - Menyimpan riwayat keputusan
   - Statistik persetujuan per orang

4. **Export Functionality**
   - Export tabel kebenaran ke PDF/Excel
   - Share hasil keputusan

---

## 📝 Kesimpulan

Integrasi antara **Tabel Kebenaran** dan **Logika Proposisional** menciptakan sistem yang:

✅ **Transparan** - Setiap hasil dapat diverifikasi  
✅ **Fleksibel** - Dapat disesuaikan dengan berbagai kebutuhan  
✅ **Edukatif** - Membantu pemahaman konsep logika  
✅ **Praktis** - Dapat digunakan dalam skenario nyata  

Sistem ini tidak hanya menyelesaikan tugas tabel kebenaran, tetapi juga memberikan nilai tambah berupa aplikasi praktis yang dapat digunakan untuk pengambilan keputusan kelompok.

---

## 📚 Referensi

- Logika Matematika Dasar
- Discrete Mathematics and Its Applications
- Boolean Algebra and Logic Gates
- Decision Theory and Group Dynamics

---

**Dibuat oleh:** Tim Pengembang  
**Tanggal:** 2025  
**Versi:** 1.0